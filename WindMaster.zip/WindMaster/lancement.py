import menu
import pygame

if __name__ == '__main__':
    vol = True
    menu.start_menu(vol)
    pygame.quit()